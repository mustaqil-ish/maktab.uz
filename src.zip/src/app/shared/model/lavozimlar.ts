
export enum Lavozim{
    ADMIN = "ADMIN",
    DIREKTOR = "DIREKTOR",
    MANAGER = "MANAGER",

}