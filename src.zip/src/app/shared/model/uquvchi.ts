export interface Uquvchi {

    id: number;
    ism: String;
    familiya: String;
    sharif: String;
    yosh: number;
    sinf: number;


}