export interface Uqituvchi {

    id: number;
    ism: String;
    familiya: String;
    yosh: number;
    jins: String;
    maosh: number;

}