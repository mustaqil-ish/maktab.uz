import { Sinfxona } from "./sinfxona";

export interface Dars {
    id: number
    sinfxona: Sinfxona;
    Fan: String;
    Uqtuvchi: String;
    Xona: number;
    UquvYili: Date; 
}