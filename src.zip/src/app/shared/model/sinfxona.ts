export interface Sinfxona {

    id:number;
    nom:string;
    boshlanganVaqt:Date;

}