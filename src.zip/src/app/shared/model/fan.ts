export  interface Fan {
    id:number;
    nom:String;
}