export interface UquvYili {

id:number;
BoshlanganVaqt:Date;
tugaganVaqt:Date;
izoh:string;

} 