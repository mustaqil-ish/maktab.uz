

export interface Togarak {
    id: number;
    oqtuvchi: string;
    fan: string;
    soat: Date;





}