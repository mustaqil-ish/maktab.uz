export interface Xona {
    id: number;
    sigim: string;
    nom: string;
    bino: string;
}